# 🟣 Ulisses.AI

Assistente de IA com frontend próprio, powered by Claude (Anthropic) no backend.

---

## Estrutura do projeto

```
ulisses-ai/
├── server.js          ← Servidor Node.js (proxy seguro para a API)
├── package.json       ← Dependências
├── .env               ← Sua chave da API (criar manualmente)
└── public/
    └── index.html     ← Frontend do chat
```

---

## Como rodar localmente

### 1. Instale o Node.js
Baixe em https://nodejs.org (versão 18+).

### 2. Instale as dependências
```bash
cd ulisses-ai
npm install
```

### 3. Configure sua chave da API
Crie um arquivo `.env` ou exporte a variável:

```bash
export ANTHROPIC_API_KEY=sk-ant-sua-chave-aqui
```

Para conseguir uma chave, acesse https://console.anthropic.com

### 4. Rode o servidor
```bash
ANTHROPIC_API_KEY=sk-ant-sua-chave-aqui node server.js
```

### 5. Acesse
Abra http://localhost:3000 no navegador.

---

## Como fazer deploy (colocar online)

### Opção A: Render.com (grátis)
1. Suba o projeto no GitHub
2. Acesse https://render.com e crie um **Web Service**
3. Conecte seu repositório
4. Configure:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Em **Environment**, adicione a variável:
   - `ANTHROPIC_API_KEY` = sua chave
6. Deploy! Você recebe uma URL tipo `https://ulisses-ai.onrender.com`

### Opção B: Railway.app
1. Acesse https://railway.app
2. Clique "Deploy from GitHub"
3. Adicione a variável `ANTHROPIC_API_KEY`
4. Pronto, deploy automático.

### Opção C: Vercel (com serverless)
Vercel funciona melhor com frameworks como Next.js. Para esse projeto simples com Express, Render ou Railway são mais diretos.

---

## Importante

- **Nunca coloque sua chave da API no código do frontend** (ela ficaria visível para qualquer pessoa)
- A chave fica segura no servidor (`server.js`), que faz a ponte entre o frontend e a API
- Cada mensagem enviada consome tokens da sua conta na Anthropic
- Monitore seu uso em https://console.anthropic.com

---

## Custo estimado

O modelo usado é o Claude Sonnet. Custo aproximado:
- ~$3 por 1 milhão de tokens de input
- ~$15 por 1 milhão de tokens de output
- Uma conversa típica usa ~1.000-3.000 tokens

Na prática, para uso pessoal/teste, o custo é bem baixo (centavos por conversa).
