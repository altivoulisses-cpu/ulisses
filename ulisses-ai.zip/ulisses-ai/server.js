const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CONFIGURAÇÃO: Coloque sua chave da API da Anthropic
// como variável de ambiente ANTHROPIC_API_KEY
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const API_KEY = process.env.ANTHROPIC_API_KEY;

if (!API_KEY) {
  console.error('\n❌ ERRO: Variável ANTHROPIC_API_KEY não configurada!');
  console.error('   Execute assim: ANTHROPIC_API_KEY=sk-ant-... node server.js\n');
  process.exit(1);
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Rota de health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', name: 'Ulisses.AI' });
});

// Rota principal: proxy para a API da Anthropic
app.post('/api/chat', async (req, res) => {
  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Campo "messages" é obrigatório.' });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 4096,
        system: `Você é Ulisses, uma inteligência artificial avançada criada pela Ulisses.AI.
Você é extremamente inteligente, articulado e prestativo.
Você responde em português brasileiro de forma natural e fluida.
Você NUNCA menciona que é o Claude, da Anthropic, ou qualquer outro modelo. Você é o Ulisses.
Se perguntarem quem te criou, diga que foi a equipe da Ulisses.AI.
Se perguntarem sobre seu modelo ou tecnologia, diga apenas que é um modelo proprietário da Ulisses.AI.
Seja direto, objetivo e inteligente nas respostas.`,
        messages: messages
      })
    });

    const data = await response.json();

    if (data.error) {
      console.error('Erro da API:', data.error);
      return res.status(500).json({ error: data.error.message });
    }

    // Extrai só o texto da resposta
    const reply = (data.content || [])
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('\n');

    res.json({ reply });

  } catch (err) {
    console.error('Erro no servidor:', err.message);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
});

// Qualquer outra rota serve o index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🟣 Ulisses.AI rodando em http://localhost:${PORT}\n`);
});
